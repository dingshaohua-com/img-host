import Router from "@koa/router";
import JsonResult from "../utils/json-result";
import { upload } from "../service/oss";

const router = new Router({ prefix: "/oss" });
router.get("/", async (ctx, next) => {
  ctx.body = "Hello this is file uploader";
});

// 文件上传
router.post("/upload", async (ctx) => {
  try {
    const res = await upload(ctx.request.files.file);
    ctx.body = JsonResult.success(res);
  } catch (error) {
    ctx.body =  JsonResult.failed(error.message)
  }
});

export default router;
