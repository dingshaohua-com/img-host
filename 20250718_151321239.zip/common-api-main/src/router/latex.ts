import katex from "katex";
import Router from "@koa/router";
import JsonResult from "../utils/json-result";

const router = new Router({ prefix: "/katex" });
router.get("/", async (ctx, next) => {
  // ctx.body = "Hello this is katex server";
  const { latex } = ctx.query;
  if (!latex) {
    ctx.body = JsonResult.failed("latex is required");
    return;
  }
  try {
    const html = katex.renderToString(latex);
    ctx.body = JsonResult.success(html);
  } catch (error) {
    ctx.body = JsonResult.failed(error.message);
  }
});

// // 文件上传
// router.get("/parse", async (ctx) => {
//   const { latex } = ctx.query;
//   const html = katex.renderToString(latex);
//   // const html = katex.renderToString('\\ce{CO2 + C -> 2 C0}');

//   // const {file} = ctx.request.files;
//   // const { newFilename, filepath } = file; // 上传上来的文件名和路径
//   // console.log('上传成功：',filepath);
//   ctx.body = JsonResult.success(html);
// });

export default router;
