import Router from "@koa/router";
import JsonResult from "../utils/json-result";
import { render, renderMathToSVG, renderMathToSVGPlus } from "../utils/mathjax-helper";

const router = new Router({ prefix: "/mathjax" });
router.get("/", async (ctx, next) => {
  // ctx.body = "Hello this is katex server";
  const { content, latex, type='latex' } = ctx.query;
  let finalContent = latex||content;

  if (!finalContent && !latex) {
    // ctx.body = JsonResult.failed("latex is required");
    // return;
    ctx.body = '';
    return;
  }
  // try {
    const result = await render(type, finalContent);
    if(type === 'latex'){
      ctx.type = 'image/svg+xml';
    }
    ctx.body = result;
  // } catch (error) {
  //   // 错误时返回空字符串，但保持 SVG 类型
  //   ctx.type = 'image/svg+xml';
  //   ctx.body = '';
  //   // ctx.body = JsonResult.failed(error.message);
  // }
});

export default router;