import Router from "@koa/router";
import JsonResult from "../utils/json-result";

const router = new Router({ prefix: "/file" });
router.get("/", async (ctx, next) => {
  ctx.body = "Hello this is file uploader";
});

// 文件上传
router.post("/upload", async (ctx) => {
  const {file} = ctx.request.files;
  const { newFilename, filepath } = file; // 上传上来的文件名和路径
  console.log('上传成功：',filepath);
  ctx.body = JsonResult.success(`/files/${newFilename}`);
});

export default router;
