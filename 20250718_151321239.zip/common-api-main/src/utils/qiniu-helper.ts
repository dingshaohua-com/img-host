const qiniu = require("qiniu");

// 配置你的七牛云Access Key和Secret Key
const accessKey = "oIzrav5AMOz0a_Ue7-Jolzwd5mHtMLgbfX28vM9O";
const secretKey = "3BxpqFAOEp9YurB8wZ0ZEy71ht010CJ9_9v6t0s4";

const mac = new qiniu.auth.digest.Mac(accessKey, secretKey);

// 配置空间名和域名
const bucket = "dingshaohua";
const domain = "http://kodo.dingshaohua.com"; // 例如：'http://qiniu.example.com'

// 生成上传凭证
function getUploadToken() {
  const options = {
    scope: bucket,
    expires: 7200, // 2小时有效期
  };
  const putPolicy = new qiniu.rs.PutPolicy(options);
  return putPolicy.uploadToken(mac);
}

export default {
  getUploadToken,
  bucket,
  domain,
};
